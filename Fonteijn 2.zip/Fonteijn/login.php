<?php

// Start session
session_start();
error_reporting(E_ERROR);
// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  session_start();
  // Get the entered username and password
  $post_username = $_POST['username'];
  $post_password = $_POST['password'];

  include("conn.php");

  // Prepare a statement to query the database for the entered username
  $sql = "SELECT password FROM tb_users WHERE username=?"; // SQL with parameters
  $stmt = $conn->prepare($sql); 
  $stmt->bind_param("i", $post_username);
  $stmt->execute();
  $result = $stmt->get_result(); // get the mysqli result

  if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    // Verify the entered password against the hashed password in the database
    if (password_verify($post_password, $row['password'])) {
      
      // Set session variable to indicate user is logged in
      $_SESSION['loggedin'] = true;

      // Check if "remember me" checkbox is checked
      if (isset($_POST['remember']) && $_POST['remember'] == '1') {
        // Set a cookie to remember the user for 1 day (86400 seconds)
        setcookie('remember_me', true, time() + 86400);
      }

      // Redirect to the homepage
      $_SESSION["loggedin"]=true;
      header('Location: reservation.php');
      exit;

    } else {
      // Authentication failed, show an error message
      $error = 'Invalid username or password';
    }

  } else {
    // Authentication failed, show an error message
    $error = 'Invalid username or password';
  }

  // Close prepared statement
  mysqli_stmt_close($stmt);

  // Close database connection
  mysqli_close($conn);

}

?>