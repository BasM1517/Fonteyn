<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400&display=swap" rel="stylesheet">
    <script src="menu.js"></script> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Fontein vakantieparken</title>
    <link rel="stylesheet" href="./style.css">
    <link rel="icon" href="./favicon.ico" type="image/x-icon">
    
  </head>

  <?php  include("login.php") ?>

<!-- Insert your HTML login form here -->
<body>
  <?php include("menu.php")?>
  <div id="main">
    <div class="flex_container_center">
      <div class="flex-child left">
        <img src="image/purple_fox2.jpg" class="logoform">
      </div>
      <div class="flex-child right" >
        <h1><b>Fonteyn <br> vakantieparken</b></h1>
        <h5><?php if(isset($error)){
          echo $error;
        }  ?></h5>
        <form action="loginpage.php" method="POST">
          <input class="input" style="color:white" type="text" placeholder="Username" name="username"><br>
          <input class="input" style="color:white" type="password" placeholder="Password" name="password"><br>
          <label for="html">Remember me <input type="checkbox" class="css-checkbox" name="remember" value="0"></label><br>
          <input style="color:white; width:20%; float:left; margin-left:75px" type="submit" value="Login"></input>
        </form>
      </div>
    </div>  
  </div>
</body>
</html>