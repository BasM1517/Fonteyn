<div id="mySidebar" class="sidebar">
  <img src="image/purple_fox2.jpg" class="logoform-menu">
  <div class="menu-container">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a class="menu_item" href="#">Reservations</a>
  </div>
  <div style="position: absolute; bottom: 10%; left:15%">
    <a href="logout.php"><div href="logout.php"style="color: #FFFFFF50;">Logout</div></a>
    </div>
</div>

<div>
  <button class="openbtn" onclick="openNav()">&#9776;</button>
</div>