
<div id="mySidebar" class="sidebar">
  <a href="landingpage.php"><img src="image/purple_fox2.jpg" class="logoform-menu"></a>
  <div class="menu-container">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a class="menu_item" href="contact.php">Contact</a>
  <a class="menu_item" href="activities.php">Activities</a>
  <a class="menu_item" href="loginpage.php">Login<a>
  </div>
</div>

<div>
  <button class="openbtn" onclick="openNav()">&#9776;</button>
</div>