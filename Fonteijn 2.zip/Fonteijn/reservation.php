
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("logincheck.php"); ?>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400&display=swap" rel="stylesheet">
    <script src="menu.js"></script> 
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Fontein vakantieparken</title>
    <link rel="stylesheet" href="./style.css">
    <link rel="icon" href="./favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
</style>
  </head>
  <body>
    <?php include("adminmenu.php")?>

    <div id="main">
        <div class="container"><h2>Reservations</h2>
        
    <?php
    // Database connection settings
    include("conn.php");
    
        // SQL query to get the number of reservations per day
        $sql = "SELECT DATE(date) as reservation_date, COUNT(*) as total_reservations FROM users GROUP BY DATE(date) ORDER BY DATE(date) ASC";

        $result = $conn->query($sql);

        $reservationData = [];

        if ($result->num_rows > 0) {
            // Output the result
            while ($row = $result->fetch_assoc()) {
                $reservationData[] = $row;
            }
        } else {
            echo "<p>No reservations found.</p>";
        }

        // Close the connection
        $conn->close();

    ?>
        

  
  
  </div>
  <div style="position:absolute;top:35%;width:70%;max-height:50vh; margin-left:5%;" class='content'>
  <canvas style="float:right;padding:0;margin:0 " id="reservationsChart"></canvas>
    </div>
        
</div>
<script>
    const reservationData = <?php echo json_encode($reservationData); ?>;
    // Extract data for labels and values
const labels = reservationData.map(data => data.reservation_date);
const values = reservationData.map(data => data.total_reservations);

// Get the canvas element and create a Chart.js instance
const ctx = document.getElementById('reservationsChart').getContext('2d');
const reservationsChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: labels,
        datasets: [{
            label: 'Reservations',
            data: values,
            backgroundColor: 'rgba(58, 49, 83, 1)',
            borderColor: 'rgba(255, 255, 255, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

</script>
  </body>
</html>
